# Libata AI — Web + Android starter

A responsive dark-futuristic Libata AI app based on the supplied dashboard design. It includes Home, AI Chat, AI Writer, Image Studio prompt builder, Idea Lab, Study Assistant, History, Settings, local prompt history, PWA install support, offline shell caching, a secure server-side AI proxy, and a Capacitor Android wrapper configuration.

## Run the web app locally

1. Install Node.js 20 or newer.
2. In this folder run `npm install`.
3. Copy `.env.example` to `.env` and set `OPENAI_API_KEY` on the server. Keep the key private; never add it to the `www` folder or commit it.
4. Load the environment variables in your hosting environment, then run `npm start`.
5. Open `http://localhost:3000`.

Without a server-side API key, the interface still runs as a preview and stores prompt history locally. Live AI requests require a configured backend.

## Publish the web app

Deploy this Node project to a Node-compatible host. Configure `OPENAI_API_KEY` and optionally `OPENAI_MODEL` as server environment variables. Use HTTPS in production so PWA installation and service-worker features work correctly.

## Build the Android app

This repository contains the Capacitor Android wrapper configuration; it is source code, not a compiled APK.

1. Install Node.js 20+, Android Studio, and the Android SDK.
2. Run `npm install`.
3. Run `npx cap add android` (first time only).
4. Run `npm run android:sync`.
5. Run `npm run android:open`, then use Android Studio to build a debug APK or a signed release APK.

The Android app should call a deployed HTTPS backend for AI features. Do not bundle an AI API key inside the APK.

## Included features and current limits

- The web interface and local navigation are implemented.
- Prompt history is stored in browser/device local storage.
- The backend proxies text requests to the OpenAI Responses API without exposing the key to the client.
- Image Studio currently creates detailed image prompts; actual image rendering needs an image-generation endpoint and UI.
- Authentication, database-backed cross-device history, billing, voice input/output, and production rate limiting are not included yet.
- No APK is prebuilt in this package; Android Studio is required to compile and sign it.
